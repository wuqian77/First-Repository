Cox.Equality <-function(alpha,beta,loghr,p1,p2,d){
  n=(qnorm(1-alpha/2)+qnorm(1-beta))^2/(loghr^2*p1*p2*d)
  return(n)
}

Cox.Equivalence <-function(alpha,beta,loghr,p1,p2,d,delta){
  n=(qnorm(1-alpha)+qnorm(1-beta/2))^2/((delta-abs(loghr))^2*p1*p2*d)
  return(n)
}

Cox.NIS <-function(alpha,beta,loghr,p1,p2,d,delta){
  n=(qnorm(1-alpha)+qnorm(1-beta))^2/((loghr-delta)^2*p1*p2*d)
  return(n)
}

TwoSampleCrossOver.Equality <-
  function(alpha,beta,sigma,margin){
    n<-(qnorm(1-alpha/2)+qnorm(1-beta))^2*sigma^2/(2*margin^2)
    return(n)
  }

TwoSampleCrossOver.NIS <-
  function(alpha,beta,sigma,delta,margin){
    n<-(qnorm(1-alpha)+qnorm(1-beta))^2*sigma^2/(2*(margin-delta)^2)
    return(n)
  }

TwoSampleCrossOver.Equivalence <-
  function(alpha,beta,sigma,delta,margin){
    if (delta==0) n<-(qnorm(1-alpha)+qnorm(1-beta/2))^2*sigma^2/(2*delta^2)
    else n<-(qnorm(1-alpha)+qnorm(1-beta/2))^2*sigma^2/(2*(delta-abs(margin))^2)
    return(n)
  }

TwoSampleProportion.Equality <-
  function(alpha,beta,p1,p2,k,delta){
    n2<-(qnorm(1-alpha/2)+qnorm(1-beta))^2*(p1*(1-p1)/k+p2*(1-p2))/delta^2
    n1<-k*n2
    return(n1)
  }

TwoSampleProportion.Equivalence <-
  function(alpha,beta,p1,p2,k,delta,margin){
    n2<-(qnorm(1-alpha)+qnorm(1-beta/2))^2*(p1*(1-p1)/k+p2*(1-p2))/(margin-abs(delta))^2
    n1<-k*n2
    return(n1)
  }

TwoSampleProportion.NIS <-
  function(alpha,beta,p1,p2,k,delta,margin){
    n2<-(qnorm(1-alpha)+qnorm(1-beta))^2*(p1*(1-p1)/k+p2*(1-p2))/(margin-delta)^2
    n1<-k*n2
    n1
    return(n1)
  }

TwoSampleMean.Equality <-
  function(alpha,beta,sigma,k,margin){
    n2<-(qnorm(1-alpha/2)+qnorm(1-beta))^2*sigma^2*(1+1/k)/margin^2
    n2
    n1<-k*n2
    return(n1)
  }

TwoSampleMean.Equivalence <-
  function(alpha,beta,sigma,k,delta,margin){
    n2<-(qnorm(1-alpha)+qnorm(1-beta/2))^2*sigma^2*(1+1/k)/(delta-abs(margin))^2
    n2
    n1<-k*n2
    return(n1)
  }

TwoSampleMean.NIS <-
  function(alpha,beta,sigma,k,delta,margin){
    n2<-(qnorm(1-alpha)+qnorm(1-beta))^2*sigma^2*(1+1/k)/(delta-margin)^2
    n2
    n1<-k*n2
    return(n1)
  }

OneSampleMean.Equality <-
  function(alpha,beta,sigma,margin){
    n<-(qnorm(1-alpha/2)+qnorm(1-beta))^2*sigma^2/margin^2
    return(n)
  }

OneSampleMean.Equivalence <-
  function(alpha,beta,sigma,margin,delta){
    if (margin==0) n<-(qnorm(1-alpha)+qnorm(1-beta/2))^2*sigma^2/delta^2
    else n<-(qnorm(1-alpha)+qnorm(1-beta))^2*sigma^2/(delta-abs(margin))^2
    return(n)
  }

OneSampleMean.NIS <-
  function(alpha,beta,sigma,margin,delta){
    n<-(qnorm(1-alpha)+qnorm(1-beta))^2*sigma^2/(margin-delta)^2
    return(n)
  }

OneSampleProportion.Equality <-
  function(alpha,beta,p,differ){
    n<-(qnorm(1-alpha/2)+qnorm(1-beta))^2*p*(1-p)/differ^2
    return(n)
  }

OneSampleProportion.Equivalence <-
  function(alpha,beta,p,delta,differ){
    n<-(qnorm(1-alpha)+qnorm(1-beta/2))^2*p*(1-p)/(delta-abs(differ))^2
    return(n)
  }


OneSampleProportion.NIS <-
  function(alpha,beta,p,delta,differ){
    n<-(qnorm(1-alpha)+qnorm(1-beta))^2*p*(1-p)/(differ-delta)^2
    return(n)
  }
